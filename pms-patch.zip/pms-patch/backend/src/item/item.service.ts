// backend/src/item/item.service.ts
// PATCH: createRoomType e updateRoomType agora criam/sincronizam HtRoom físicos
import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateRoomTypeDto } from './dto/create-room-type.dto';
import { UpdateRoomTypeDto } from './dto/update-room-type.dto';

@Injectable()
export class ItemService {
  constructor(private readonly prisma: PrismaService) {}

  // ─── Helpers ──────────────────────────────────────────────────────────────

  /** Gera o próximo número de quarto disponível para o negócio.
   *  Usa padding numérico: 101, 102 … ou texto livre se já houver padrão. */
  private async nextRoomNumber(businessId: string, floor: number): Promise<string> {
    const existing = await this.prisma.htRoom.findMany({
      where: { businessId },
      select: { number: true },
    });
    const nums = existing
      .map(r => parseInt(r.number, 10))
      .filter(n => !isNaN(n));
    const max = nums.length ? Math.max(...nums) : (floor * 100);
    return String(max + 1);
  }

  /** Cria N quartos físicos para um HtRoomType recém-criado. */
  private async createPhysicalRooms(
    businessId: string,
    roomTypeId: string,
    totalRooms: number,
    floor: number,
  ): Promise<void> {
    for (let i = 0; i < totalRooms; i++) {
      const number = await this.nextRoomNumber(businessId, floor);
      await this.prisma.htRoom.create({
        data: { businessId, roomTypeId, number, floor, status: 'CLEAN' },
      });
    }
  }

  /** Sincroniza os quartos físicos quando totalRooms muda num tipo existente.
   *  - Se aumentou: cria os extras.
   *  - Se diminuiu: remove os CLEAN sem reservas activas (mais antigos). */
  private async syncPhysicalRooms(
    businessId: string,
    roomTypeId: string,
    newTotal: number,
    floor: number,
  ): Promise<void> {
    const current = await this.prisma.htRoom.findMany({
      where: { businessId, roomTypeId },
      include: { bookings: { where: { status: { in: ['CONFIRMED','CHECKED_IN','PENDING'] } } } },
      orderBy: { createdAt: 'asc' },
    });

    const diff = newTotal - current.length;

    if (diff > 0) {
      // Criar quartos extra
      for (let i = 0; i < diff; i++) {
        const number = await this.nextRoomNumber(businessId, floor);
        await this.prisma.htRoom.create({
          data: { businessId, roomTypeId, number, floor, status: 'CLEAN' },
        });
      }
    } else if (diff < 0) {
      // Remover quartos sem reservas activas (os mais antigos primeiro)
      const removable = current
        .filter(r => r.bookings.length === 0 && r.status === 'CLEAN')
        .slice(0, Math.abs(diff));
      for (const r of removable) {
        await this.prisma.htRoom.delete({ where: { id: r.id } });
      }
    }
  }

  // ─── Items genéricos ───────────────────────────────────────────────────────

  findAll() {
    return this.prisma.item.findMany();
  }

  findOne(id: string) {
    return this.prisma.item.findUnique({ where: { id } });
  }

  create(createItemDto: any) {
    return this.prisma.item.create({ data: createItemDto });
  }

  update(id: string, updateItemDto: any) {
    return this.prisma.item.update({ where: { id }, data: updateItemDto });
  }

  remove(id: string) {
    return this.prisma.item.delete({ where: { id } });
  }

  // ─── Menu ──────────────────────────────────────────────────────────────────

  getMenuByBusiness(businessId: string) {
    return this.prisma.diMenuItem.findMany({ where: { businessId } });
  }

  async createMenuItem(ownerId: string, dto: any) {
    const business = await this.prisma.business.findUnique({
      where: { id: dto.businessId },
      select: { id: true, ownerId: true },
    });
    if (!business) throw new NotFoundException('Estabelecimento não encontrado.');
    if (business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode adicionar itens.');
    return this.prisma.diMenuItem.create({ data: { ...dto } });
  }

  async updateMenuItem(id: string, ownerId: string, dto: any) {
    const item = await this.prisma.diMenuItem.findUnique({
      where: { id },
      include: { business: { select: { ownerId: true } } },
    });
    if (!item) throw new NotFoundException('Item não encontrado.');
    if (item.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode editar itens.');
    return this.prisma.diMenuItem.update({ where: { id }, data: dto });
  }

  async removeMenuItem(id: string, ownerId: string) {
    const item = await this.prisma.diMenuItem.findUnique({
      where: { id },
      include: { business: { select: { ownerId: true } } },
    });
    if (!item) throw new NotFoundException('Item não encontrado.');
    if (item.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode remover itens.');
    await this.prisma.diMenuItem.delete({ where: { id } });
    return { message: 'Item removido com sucesso.' };
  }

  // ─── Inventário ───────────────────────────────────────────────────────────

  getInventoryByBusiness(businessId: string) {
    return this.prisma.diInventoryItem.findMany({ where: { businessId } });
  }

  async createInventoryItem(ownerId: string, dto: any) {
    const business = await this.prisma.business.findUnique({
      where: { id: dto.businessId },
      select: { id: true, ownerId: true },
    });
    if (!business) throw new NotFoundException('Estabelecimento não encontrado.');
    if (business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode adicionar itens de inventário.');
    return this.prisma.diInventoryItem.create({ data: { ...dto } });
  }

  async updateInventoryItem(id: string, ownerId: string, dto: any) {
    const item = await this.prisma.diInventoryItem.findUnique({
      where: { id },
      include: { business: { select: { ownerId: true } } },
    });
    if (!item) throw new NotFoundException('Item de inventário não encontrado.');
    if (item.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode editar itens de inventário.');
    return this.prisma.diInventoryItem.update({ where: { id }, data: dto });
  }

  async removeInventoryItem(id: string, ownerId: string) {
    const item = await this.prisma.diInventoryItem.findUnique({
      where: { id },
      include: { business: { select: { ownerId: true } } },
    });
    if (!item) throw new NotFoundException('Item de inventário não encontrado.');
    if (item.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode remover itens.');
    await this.prisma.diInventoryItem.delete({ where: { id } });
    return { message: 'Item de inventário removido com sucesso.' };
  }

  // ─── Serviços ─────────────────────────────────────────────────────────────

  getServicesByBusiness(businessId: string) {
    return this.prisma.proService.findMany({ where: { businessId } });
  }

  async createService(ownerId: string, dto: any) {
    const business = await this.prisma.business.findUnique({
      where: { id: dto.businessId },
      select: { id: true, ownerId: true },
    });
    if (!business) throw new NotFoundException('Estabelecimento não encontrado.');
    if (business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode adicionar serviços.');
    return this.prisma.proService.create({ data: { ...dto } });
  }

  async updateService(id: string, ownerId: string, dto: any) {
    const service = await this.prisma.proService.findUnique({
      where: { id },
      include: { business: { select: { ownerId: true } } },
    });
    if (!service) throw new NotFoundException('Serviço não encontrado.');
    if (service.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode editar serviços.');
    return this.prisma.proService.update({ where: { id }, data: dto });
  }

  async removeService(id: string, ownerId: string) {
    const service = await this.prisma.proService.findUnique({
      where: { id },
      include: { business: { select: { ownerId: true } } },
    });
    if (!service) throw new NotFoundException('Serviço não encontrado.');
    if (service.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode remover serviços.');
    await this.prisma.proService.delete({ where: { id } });
    return { message: 'Serviço removido com sucesso.' };
  }

  // ─── Tipos de Quarto (HtRoomType) ─────────────────────────────────────────

  getRoomsByBusiness(businessId: string) {
    return this.prisma.htRoomType.findMany({
      where:   { businessId },
      include: { rooms: { select: { id: true, number: true, floor: true, status: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async createRoomType(ownerId: string, dto: any) {
    const business = await this.prisma.business.findUnique({
      where: { id: dto.businessId },
      select: { id: true, ownerId: true },
    });
    if (!business) throw new NotFoundException('Estabelecimento não encontrado.');
    if (business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode adicionar tipos de quarto.');

    const total = dto.totalRooms ?? 1;
    const floor = dto.floor ?? 1;

    // 1. Criar o tipo abstracto
    const roomType = await this.prisma.htRoomType.create({
      data: {
        businessId:        dto.businessId,
        name:              dto.name,
        description:       dto.description       ?? '',
        pricePerNight:     dto.pricePerNight,
        maxGuests:         dto.maxGuests          ?? 2,
        totalRooms:        total,
        available:         dto.available          !== false,
        amenities:         dto.amenities          ?? [],
        minNights:         dto.minNights          ?? 1,
        taxRate:           dto.taxRate            ?? 0,
        weekendMultiplier: dto.weekendMultiplier  ?? 1.0,
        seasonalRates:     dto.seasonalRates      ?? undefined,
        photos:            dto.photos             ?? [],
      },
    });

    // 2. Criar os quartos físicos (HtRoom) automaticamente
    await this.createPhysicalRooms(dto.businessId, roomType.id, total, floor);

    // Retornar com os quartos criados
    return this.prisma.htRoomType.findUnique({
      where:   { id: roomType.id },
      include: { rooms: { select: { id: true, number: true, floor: true, status: true } } },
    });
  }

  async updateRoomType(id: string, ownerId: string, dto: any) {
    const roomType = await this.prisma.htRoomType.findUnique({
      where:   { id },
      include: { business: { select: { ownerId: true, id: true } } },
    });
    if (!roomType) throw new NotFoundException('Tipo de quarto não encontrado.');
    if (roomType.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode editar tipos de quarto.');

    const data: any = {};
    if (dto.name              !== undefined) data.name              = dto.name;
    if (dto.description       !== undefined) data.description       = dto.description;
    if (dto.pricePerNight     !== undefined) data.pricePerNight     = dto.pricePerNight;
    if (dto.maxGuests         !== undefined) data.maxGuests         = dto.maxGuests;
    if (dto.totalRooms        !== undefined) data.totalRooms        = dto.totalRooms;
    if (dto.available         !== undefined) data.available         = dto.available;
    if (dto.amenities         !== undefined) data.amenities         = dto.amenities;
    if (dto.minNights         !== undefined) data.minNights         = dto.minNights;
    if (dto.taxRate           !== undefined) data.taxRate           = dto.taxRate;
    if (dto.weekendMultiplier !== undefined) data.weekendMultiplier = dto.weekendMultiplier;
    if (dto.seasonalRates     !== undefined) data.seasonalRates     = dto.seasonalRates as any;
    if (dto.photos            !== undefined) data.photos            = dto.photos;

    const updated = await this.prisma.htRoomType.update({ where: { id }, data });

    // Sincronizar quartos físicos se totalRooms mudou
    if (dto.totalRooms !== undefined && dto.totalRooms !== roomType.totalRooms) {
      const floor = dto.floor ?? 1;
      await this.syncPhysicalRooms(roomType.business.id, id, dto.totalRooms, floor);
    }

    return this.prisma.htRoomType.findUnique({
      where:   { id },
      include: { rooms: { select: { id: true, number: true, floor: true, status: true } } },
    });
  }

  async removeRoomType(id: string, ownerId: string) {
    const roomType = await this.prisma.htRoomType.findUnique({
      where:   { id },
      include: { business: { select: { ownerId: true } } },
    });
    if (!roomType) throw new NotFoundException('Tipo de quarto não encontrado.');
    if (roomType.business.ownerId !== ownerId)
      throw new ForbiddenException('Apenas o proprietário pode remover tipos de quarto.');

    // Remover quartos físicos sem reservas activas
    await this.prisma.htRoom.deleteMany({
      where: {
        roomTypeId: id,
        bookings:   { none: { status: { in: ['CONFIRMED','CHECKED_IN','PENDING'] } } },
      },
    });

    await this.prisma.htRoomType.delete({ where: { id } });
    return { message: 'Tipo de quarto e quartos físicos removidos com sucesso.' };
  }
}
